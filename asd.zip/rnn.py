# # 使用tensorflow框架，利用循环神经网络进行短句训练“ china is the best”。
# import tensorflow as tf
# import numpy as np
# import os
# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
# # (一)	建立字典（8分）
# sample = ' china is the best'
# idx = list(set(sample))
# char2idx = {c:i for i,c in enumerate(idx)}
# print(char2idx.get(1))
# # (二)	构造数据集x_data,y_data（8分）
# sam_code = [char2idx[c] for c in sample]
# print(sam_code)
# x_data = [sam_code[:-1]]
# y_data = [sam_code[1:]]
# # (三)	设置参数（8分）
# num_classes = len(char2idx)
# hidden_size = 8
# batch_size = 1
# input_dim = len(char2idx)
# squence_length = len(sam_code) - 1
# learning_rate = 0.1
# # (四)	定义占位符（8分）
# X = tf.placeholder(dtype=tf.int64,shape=[None,squence_length])
# Y = tf.placeholder(dtype=tf.int64,shape=[None,squence_length])
# x_ont_hot = tf.one_hot(X,depth=num_classes)
#
# # (五)	定义LSTM单元（4分）、堆叠多层RNN单元（4分）、调用动态RNN函数（4分）
# cell1 = tf.contrib.rnn.BasicLSTMCell(num_units=hidden_size,state_is_tuple=True)
# cell2 = tf.contrib.rnn.BasicLSTMCell(num_units=hidden_size,state_is_tuple=True)
# cells = tf.contrib.rnn.MultiRNNCell([cell1,cell2])
# outputs,state_ = tf.nn.dynamic_rnn(cells,x_ont_hot,dtype=tf.float32)
# # (六)	定义全连接层（8分）
# x_fc = tf.reshape(outputs,[-1,hidden_size])
# outputs = tf.contrib.layers.fully_connected(inputs=x_fc,num_outputs=num_classes,activation_fn=None)
# # (七)	计算序列损失（8分）
# x_for_loss = tf.reshape(outputs,[batch_size,squence_length,num_classes])
# weights = tf.ones([batch_size,squence_length])
# loss = tf.contrib.seq2seq.sequence_loss(logits=x_for_loss,targets=Y,weights=weights)
#
# optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)
# # (八)	定义准确率计算模型（8分）
# pre = tf.argmax(x_for_loss,axis=2)
# acc = tf.reduce_mean(tf.cast(tf.equal(pre,Y),dtype=float))
#
# with tf.Session() as session:
#     session.run(tf.global_variables_initializer())
#     # (九)	开始训练迭代100次（8分）
#     for i in range(100):
#         loss_,acc_,_ = session.run([loss,acc,optimizer],feed_dict={X:x_data,Y:y_data})
#         # (十)	输出损失值、准确率（8分）
#         print(i,'loss=',loss_,'acc=',acc_)
#         # (十一)	预测结果查字典后输出字符串（8分）
#         pre_ = session.run(pre,feed_dict={X:x_data})
#         pre_str = [idx[c] for c in np.squeeze(pre_)]
#         print('字符串:',''.join(pre_str) )
#     # (十二)	用一个新的数据“the best is china”进行测试，以字符串格式输出预测的结果（8分）
#     testx = 'the best is china'
#     testx_code = [char2idx[c] for c in testx]
#     pre_ = session.run(pre, feed_dict={X: [testx_code]})
#     pre_str = [idx[c] for c in np.squeeze(pre_)]
#     print('字符串:', ''.join(pre_str))


# 使用tensorflow框架，利用循环神经网络进行短句训练“ china is the best”。
import tensorflow as tf
import numpy as np
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
# (一)	建立字典（8分）
sample = ' china is the best'
idx2 = list(set(sample))
char2 = {c:i for i,c in enumerate(idx2)}
# (二)	构造数据集x_data,y_data（8分）
sample_code = [char2[c] for c in sample]
x_data = [sample_code[:-1]]
y_data = [sample_code[1:]]
# (三)	设置参数（8分）
num_classes = len(idx2)
hidden_size = 8
squence_length = len(sample) -1
batch_size = 1
input_dim = len(idx2)
learning_rate = 0.1

# (四)	定义占位符（8分）
X = tf.placeholder(tf.int64,[None,squence_length])
Y = tf.placeholder(tf.int64,[None,squence_length])
x_ont_hot = tf.one_hot(X,depth=num_classes)
# (五)	定义LSTM单元（4分）、堆叠多层RNN单元（4分）、调用动态RNN函数（4分）
cells = [tf.contrib.rnn.BasicLSTMCell(num_units=hidden_size) for _ in range(2)]
mulcells = tf.contrib.rnn.MultiRNNCell(cells)
initial_state = mulcells.zero_state(batch_size,dtype=tf.float32)
outputs,_state = tf.nn.dynamic_rnn(mulcells,x_ont_hot,initial_state=initial_state,dtype=tf.float32)
# (六)	定义全连接层（8分）
outputs = tf.reshape(outputs,[-1,hidden_size])
outputs = tf.contrib.layers.fully_connected(inputs=outputs,num_outputs=num_classes,activation_fn=None)
# (七)	计算序列损失（8分）
outputs = tf.reshape(outputs,[batch_size,squence_length,input_dim])
wights = tf.ones([batch_size,squence_length])
loss = tf.contrib.seq2seq.sequence_loss(logits=outputs,targets=Y,weights=wights)

optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(loss)
# (八)	定义准确率计算模型（8分）
pre = tf.argmax(outputs,axis=2)
acc = tf.reduce_mean(tf.cast(tf.equal(pre,Y),dtype=float))

with tf.Session() as session:
    session.run(tf.global_variables_initializer())
    # (九)	开始训练迭代100次（8分）
    for i in range(100):
        loss_,acc_,_ = session.run([loss,acc,optimizer],feed_dict={X:x_data,Y:y_data})
    # (十)	输出损失值、准确率（8分）
        print(i,'loss=',loss_,'acc=',acc_)
    # (十一)	预测结果查字典后输出字符串（8分）
        prediction = session.run(pre,feed_dict={X:x_data})
        pre_str = [idx2[i] for i in np.squeeze(prediction)]
        print('预测结果:',''.join(pre_str))
    # (十二)	用一个新的数据“the best is china”进行测试，以字符串格式输出预测的结果（8分）
    test = 'the best is china'
    test_code = [char2[c] for c in test]
    prediction = session.run(pre, feed_dict={X: [test_code]})
    pre_str = [idx2[i] for i in np.squeeze(prediction)]
    print('预测结果:', ''.join(pre_str))






















